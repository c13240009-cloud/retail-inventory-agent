import io
import numpy as np
import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

st.set_page_config(page_title='Retail Inventory Agent', page_icon='📦', layout='wide')
st.title('📦 Retail Inventory & Replenishment Agent')
st.caption('Prototipe demo: threshold stok bukan SOP resmi perusahaan.')

KB = [
 {'id':'INV-001','topic':'Tujuan inventory agent','text':'Agent membantu menganalisis persediaan, membandingkan Inventory Level dengan Demand, menemukan produk yang perlu diperhatikan, dan memberikan rekomendasi awal. Rekomendasi bukan keputusan pembelian otomatis.'},
 {'id':'INV-002','topic':'Kategori kondisi stok','text':'Untuk demonstrasi, Stock Ratio dihitung Inventory Level dibagi Demand jika Demand lebih besar dari nol. Rasio <= 0.5 berarti Prioritas tinggi. Rasio > 0.5 sampai 1.0 berarti Perlu dipantau. Rasio > 1.0 sampai 1.5 berarti Stok relatif aman. Rasio > 1.5 berarti Evaluasi stok berlebih. Ini aturan demo, bukan kebijakan resmi.'},
 {'id':'INV-003','topic':'Data tidak valid','text':'Jika Inventory Level atau Demand kosong, bukan angka, atau negatif, data harus diperiksa. Jika Demand nol, Stock Ratio tidak dapat dihitung dengan pembagian biasa. Jangan mengarang nilai yang hilang.'},
 {'id':'INV-004','topic':'Arti kolom','text':'Inventory Level menunjukkan nilai stok menurut dataset. Demand menunjukkan permintaan menurut dataset. Units Sold menunjukkan jumlah terjual. Units Ordered menunjukkan nilai pesanan, tetapi tidak otomatis berarti pesanan pembelian masih terbuka. Makna dan satuan kolom perlu dikonfirmasi kepada pemilik data.'},
 {'id':'INV-005','topic':'Replenishment','text':'Rekomendasi jumlah replenishment yang akurat memerlukan target stok, lead time pemasok, stok yang sudah dipesan tetapi belum diterima, dan aturan persediaan. Jika parameter belum tersedia, jangan mengarang jumlah pemesanan.'},
 {'id':'INV-006','topic':'Persetujuan manusia','text':'Rekomendasi agent perlu ditinjau petugas berwenang. Agent tidak membuat atau mengirim purchase order otomatis. Keputusan pembelian memerlukan persetujuan manusia dan pemeriksaan data.'},
 {'id':'INV-007','topic':'Keterbatasan analisis','text':'Perbandingan Inventory Level dan Demand saja tidak membuktikan produk pasti kehabisan atau kelebihan stok. Hasilnya indikator awal berdasarkan aturan demo, bukan prediksi pasti.'},
 {'id':'INV-008','topic':'Informasi tidak tersedia','text':'Jika pertanyaan tidak dapat dijawab dari sumber pengetahuan yang ditemukan, nyatakan informasi belum tersedia. Jangan mengarang SOP, jam operasional, lead time, supplier, atau kebijakan perusahaan.'}
]

@st.cache_resource
def get_retriever():
    v = TfidfVectorizer(lowercase=True, ngram_range=(1,2), sublinear_tf=True)
    m = v.fit_transform([x['text'] for x in KB])
    return v, m

def retrieve(q, k=3, min_score=0.08):
    v, m = get_retriever()
    scores = cosine_similarity(v.transform([q]), m)[0]
    out = []
    for i in scores.argsort()[::-1][:k]:
        if float(scores[i]) >= min_score:
            out.append({**KB[i], 'score': round(float(scores[i]), 3)})
    return out

@st.cache_resource
def load_llm():
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM
    name = 'Qwen/Qwen2.5-0.5B-Instruct'
    tok = AutoTokenizer.from_pretrained(name)
    mdl = AutoModelForCausalLM.from_pretrained(name, torch_dtype='auto', device_map='auto')
    return tok, mdl

def rag_answer(q, use_llm):
    docs = retrieve(q)
    if not docs:
        return 'Informasi belum tersedia dalam knowledge base. Tambahkan aturan atau dokumen relevan.', []
    context = '\n\n'.join(f"[{d['id']} - {d['topic']}] {d['text']}" for d in docs)
    if use_llm:
        try:
            import torch
            tok, mdl = load_llm()
            messages = [
              {'role':'system','content':'Kamu adalah Retail Inventory & Replenishment Agent. Jawab dalam Bahasa Indonesia, hanya berdasarkan konteks. Jangan mengarang fakta. Jelaskan bahwa threshold adalah aturan demo, bukan SOP resmi. Jika konteks tidak cukup, nyatakan informasi belum tersedia.'},
              {'role':'user','content':f'KONTEKS:\n{context}\n\nPERTANYAAN:\n{q}\n\nJawab ringkas dan sebutkan ID sumber.'}
            ]
            prompt = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            inputs = tok(prompt, return_tensors='pt').to(mdl.device)
            with torch.no_grad():
                output = mdl.generate(**inputs, max_new_tokens=180, do_sample=False, pad_token_id=tok.eos_token_id)
            answer = tok.decode(output[0][inputs['input_ids'].shape[1]:], skip_special_tokens=True).strip()
        except Exception as e:
            answer = 'Model bahasa gagal dimuat. Konteks retrieval yang ditemukan:\n\n' + context + f'\n\nDetail teknis: {type(e).__name__}. Coba koneksi internet dan resource runtime yang memadai.'
    else:
        answer = '\n\n'.join(f"**{d['topic']} ({d['id']})**\n{d['text']}" for d in docs)
    sources = [{'id':d['id'],'topic':d['topic'],'score':d['score']} for d in docs]
    return answer, sources

def analyze(df):
    for col in ['Inventory Level','Demand']:
        if col not in df.columns:
            raise ValueError(f'Kolom wajib tidak ditemukan: {col}')
    out = df.copy()
    for col in ['Inventory Level','Demand']:
        out[col] = pd.to_numeric(out[col], errors='coerce')
    def label(r):
        stock, demand = r['Inventory Level'], r['Demand']
        if pd.isna(stock) or pd.isna(demand) or stock < 0 or demand < 0: return 'Periksa data'
        if demand == 0: return 'Periksa demand'
        ratio = stock / demand
        if ratio <= 0.5: return 'Prioritas tinggi'
        if ratio <= 1.0: return 'Perlu dipantau'
        if ratio <= 1.5: return 'Stok relatif aman'
        return 'Evaluasi stok berlebih'
    out['Stock Ratio'] = np.where(out['Demand'] > 0, out['Inventory Level'] / out['Demand'], np.nan)
    out['Recommendation'] = out.apply(label, axis=1)
    return out

with st.sidebar:
    st.header('Pengaturan')
    file = st.file_uploader('Upload file inventory', type=['xlsx','xls','csv'])
    use_llm = st.checkbox('Gunakan model bahasa untuk RAG', value=True, help='Model diunduh saat pertama kali dipakai; butuh internet dan resource yang cukup.')

if file:
    try:
        df = pd.read_csv(file) if file.name.lower().endswith('.csv') else pd.read_excel(file)
        df.columns = df.columns.astype(str).str.strip()
        result = analyze(df)
        st.subheader('Ringkasan data')
        a,b,c,d = st.columns(4)
        a.metric('Total baris', f'{len(result):,}')
        b.metric('Prioritas tinggi', int((result['Recommendation']=='Prioritas tinggi').sum()))
        c.metric('Perlu dipantau', int((result['Recommendation']=='Perlu dipantau').sum()))
        d.metric('Evaluasi stok berlebih', int((result['Recommendation']=='Evaluasi stok berlebih').sum()))
        st.subheader('Data inventory')
        options = ['Semua'] + result['Recommendation'].dropna().unique().tolist()
        chosen = st.selectbox('Filter rekomendasi', options)
        shown = result if chosen == 'Semua' else result[result['Recommendation'] == chosen]
        st.dataframe(shown, use_container_width=True, height=360)
        st.download_button('Download hasil CSV', result.to_csv(index=False).encode('utf-8-sig'), 'retail_inventory_result.csv', 'text/csv')
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine='openpyxl') as writer:
            result.to_excel(writer, index=False, sheet_name='Inventory Analysis')
        st.download_button('Download hasil Excel', buf.getvalue(), 'retail_inventory_result.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    except Exception as e:
        st.error(f'Gagal membaca atau menganalisis data: {e}')
else:
    st.info('Upload file Excel atau CSV melalui panel kiri untuk memulai.')
    st.write('Kolom minimal: `Inventory Level` dan `Demand`. Kolom Store ID/Product ID disarankan untuk identifikasi produk.')

st.divider()
st.subheader('💬 Tanya Inventory Agent (RAG)')
st.write('Tanyakan aturan kategori stok, arti kolom, atau kebutuhan informasi replenishment.')
if 'history' not in st.session_state: st.session_state.history = []
for msg in st.session_state.history:
    with st.chat_message(msg['role']):
        st.markdown(msg['content'])
        if msg.get('sources'):
            with st.expander('Sumber knowledge base'):
                for s in msg['sources']:
                    st.write(f"{s['id']} — {s['topic']} (skor retrieval: {s['score']})")
q = st.chat_input('Contoh: Kapan stok disebut evaluasi stok berlebih?')
if q:
    st.session_state.history.append({'role':'user','content':q})
    with st.chat_message('user'): st.markdown(q)
    with st.chat_message('assistant'):
        with st.spinner('Mencari konteks dan menyusun jawaban...'):
            answer, sources = rag_answer(q, use_llm)
        st.markdown(answer)
        if sources:
            with st.expander('Sumber knowledge base'):
                for s in sources: st.write(f"{s['id']} — {s['topic']} (skor retrieval: {s['score']})")
    st.session_state.history.append({'role':'assistant','content':answer,'sources':sources})
